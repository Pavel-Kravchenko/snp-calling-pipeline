a=*.fas*
export PATH=${PATH}:../hisat2-2.1.0
for x in $a
do
 hisat2-build $x ${x%.fa*}
done
